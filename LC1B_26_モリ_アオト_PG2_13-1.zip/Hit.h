#pragma once
#include "Object.h"

int Hit(Vector2 posA, float radiusA, Vector2 posB, float radiusB);

